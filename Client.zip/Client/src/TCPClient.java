import java.io.*;
import java.net.*;

public class TCPClient {
	public static void main(String argv[]) throws Exception {
		String sentence ;
		String modifiedSentence ;
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(
				System.in));
		Socket clientSocket = new Socket("172.20.10.2",6789);
		sentence=inFromUser.readLine();
		if (sentence.equals("CONNECT")) {
			System.out.println("CONNECTION ESTABLISHED");
			while (true) {

				DataOutputStream outToServer = new DataOutputStream(
						clientSocket.getOutputStream());

				BufferedReader inFromServer = new BufferedReader(
						new InputStreamReader(clientSocket.getInputStream()));
				BufferedReader inFromUser3 = new BufferedReader(new InputStreamReader(System.in));

				sentence = inFromUser.readLine();
				//System.out.println(modifiedSentence);

				if (sentence.equals("BYE")) {

					clientSocket.close();
					return;

				}
				else {
					outToServer.writeBytes(sentence +'\n');
					outToServer.flush();
					modifiedSentence=inFromServer.readLine();
					System.out.println("SERVER"+modifiedSentence);
				}

			}

		}
	}
}



